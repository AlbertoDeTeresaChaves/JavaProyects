package com.curso.controlador;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.curso.modelo.Socio;
import com.curso.dao.SocioDAO;
import com.curso.dao.SocioDAOImplementacion;

/**
 * Servlet implementation class SvSocios
 */
@WebServlet("/SvSocios")
public class SvSocios extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private SocioDAO dao;
    
	private static final Integer MAX_ELEMENTOS_PAGINA = 5;
	private static final String LIST_STUDENT = "/ListaSocios.jsp";
	private static final String INSERT_OR_EDIT = "/Socio.jsp";
	private static final String ACTUALIZAR = "/socio_actualizar.jsp";
	
    public SvSocios() {
        dao = new SocioDAOImplementacion();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		String forward = "";
		String action = request.getParameter("action");
		
		if(action.equals("delete")) {
			forward = LIST_STUDENT;
			int Id = Integer.parseInt(request.getParameter("socioID"));
			dao.BorrarSocio(Id);
			request.setAttribute("VSocios", dao.getAllsocios());
		}else if(action.equalsIgnoreCase("update")) {
			forward = ACTUALIZAR;
			int Id = Integer.parseInt(request.getParameter("socioID"));
			Socio so = dao.getsocioById(Id);
			request.setAttribute("VSocio", so);
			
		}else if(action.equals("insert")) {
			forward = INSERT_OR_EDIT;
		}else {
			forward = LIST_STUDENT;
			request.setAttribute("VSocios",dao.getAllsocios());
		}
		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Socio so = new Socio();
		
		so.setNombre(request.getParameter("nombre"));
		so.setEstatura(Integer.parseInt(request.getParameter("estatura")));
		so.setEdad(Integer.parseInt(request.getParameter("edad")));
		so.setLocalidad(request.getParameter("localidad"));
		
		try {
			String a=request.getParameter("old_id");
			so.setSocioID(Integer.parseInt(request.getParameter("socioID")));
			dao.ActualizarSocio(Integer.parseInt(a),so);
		}catch(Exception ex) {
			so.setSocioID(dao.idNuevo());
			dao.AñadirSocio(so);
		}
		RequestDispatcher view = request.getRequestDispatcher(LIST_STUDENT);
		request.setAttribute("VSocios", dao.getAllsocios());
		view.forward(request, response);
	}
	

}
