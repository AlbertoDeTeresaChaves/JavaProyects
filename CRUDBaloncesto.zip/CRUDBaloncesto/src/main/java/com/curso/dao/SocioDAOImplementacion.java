package com.curso.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.curso.modelo.Socio;
import com.curso.util.DBUtil;

public class SocioDAOImplementacion implements SocioDAO {
private Connection conn;

	public SocioDAOImplementacion() {
	conn = DBUtil.getConnection();
}

	@Override
	public void AñadirSocio(Socio socio) {
		// TODO Auto-generated method stub
		try {
			String query="insert into socio values(?,?,?,?,?)";
			PreparedStatement s =conn.prepareStatement(query);
			s.setInt(1, socio.getSocioID());
			s.setString(2, socio.getNombre());
			s.setInt(3, socio.getEstatura());
			s.setInt(4, socio.getEdad());
			s.setString(5,socio.getLocalidad());
			
			s.executeUpdate();
			s.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}catch(NumberFormatException e) {
			System.out.println("Error");
		}
	}

	@Override
	public void BorrarSocio(int id) {
		// TODO Auto-generated method stub
		try {
			String query="delete from socio where socioID=?";
			PreparedStatement s=conn.prepareStatement(query);
			s.setInt(1, id);
			s.executeUpdate();
			s.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void ActualizarSocio(int id, Socio socio) {
		// TODO Auto-generated method stub
		try {
			String query="update socio set socioID=?, Nombre=?, Estatura=?, Edad=?, Localidad=? where socioID=?";
			PreparedStatement s=conn.prepareStatement(query);
			s.setInt(1, socio.getSocioID());
			s.setString(2,socio.getNombre());
			s.setInt(3, socio.getEstatura());
			s.setInt(4, socio.getEdad());
			s.setString(5, socio.getLocalidad());
			s.setInt(6, id);
			
			s.executeUpdate();
			s.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<Socio> getAllsocios() {
		// TODO Auto-generated method stub
		List <Socio> ls = new ArrayList<Socio>();
		try {
			Statement statement = conn.createStatement();
			ResultSet r = statement.executeQuery("select * from socio");
			while(r.next()) {
				Socio so = new Socio();
				so.setSocioID(r.getInt(1));
				so.setNombre(r.getString(2));
				so.setEstatura(r.getInt(3));
				so.setEdad(r.getInt(4));
				so.setLocalidad(r.getString(5));
				ls.add(so);
				}		
			r.close();
			statement.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		return ls;
	}

	@Override
	public Socio getsocioById(int id) {
		// TODO Auto-generated method stub
		Socio so = new Socio();
		try {
			String query="select * from socio where socioID=?";
			PreparedStatement preparedStatement = conn.prepareStatement(query);
			preparedStatement.setInt(1,id);
			ResultSet r = preparedStatement.executeQuery();
			while(r.next()) {
			so.setSocioID(r.getInt("socioID"));
			so.setNombre(r.getString("nombre"));
			so.setEstatura(r.getInt("estatura"));
			so.setEdad(r.getInt("edad"));
			so.setLocalidad(r.getString("localidad"));
			}
			r.close();
			preparedStatement.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return so;
	}

	@Override
	public int idNuevo() {
		// TODO Auto-generated method stub
		int n=0;
		try {
			String query = "select max(socioID)+1 from socio";
			PreparedStatement preparedStatement = conn.prepareStatement(query);
			ResultSet r = preparedStatement.executeQuery();
			while(r.next()) {
				n=r.getInt(1);
			}
			r.close();
			preparedStatement.close();
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
		return n;
	}

}
