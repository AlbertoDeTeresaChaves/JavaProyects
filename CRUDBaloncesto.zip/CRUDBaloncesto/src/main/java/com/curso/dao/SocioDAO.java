package com.curso.dao;

import java.util.List;

import com.curso.modelo.Socio;
public interface SocioDAO {

	public void AñadirSocio(Socio socio);
	public void BorrarSocio(int id);
	public void ActualizarSocio(int id,Socio socio);
	public List <Socio> getAllsocios();
	public Socio getsocioById(int id);
	public int idNuevo();
}
