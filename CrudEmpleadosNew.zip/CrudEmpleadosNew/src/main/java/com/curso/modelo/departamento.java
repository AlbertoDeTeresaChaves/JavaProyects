package com.curso.modelo;

public class departamento {
	
private int DEPTNO;
private String DNAME;
private String LOC;

public departamento() {
	super();
	// TODO Auto-generated constructor stub
}
public departamento(int dEPTNO, String dNAME, String lOC) {
	super();
	DEPTNO = dEPTNO;
	DNAME = dNAME;
	LOC = lOC;
}
public int getDEPTNO() {
	return DEPTNO;
}
public void setDEPTNO(int dEPTNO) {
	DEPTNO = dEPTNO;
}
public String getDNAME() {
	return DNAME;
}
public void setDNAME(String dNAME) {
	DNAME = dNAME;
}
public String getLOC() {
	return LOC;
}
public void setLOC(String lOC) {
	LOC = lOC;
}
@Override
public String toString() {
	return "departamento [DEPTNO=" + DEPTNO + ", DNAME=" + DNAME + ", LOC=" + LOC + "]";
}


}
