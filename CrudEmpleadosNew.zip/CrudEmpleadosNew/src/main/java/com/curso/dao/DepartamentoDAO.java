package com.curso.dao;
import java.util.List;
import com.curso.modelo.departamento;

public interface DepartamentoDAO {

	public void AñadirDepartamento(departamento dept);
	public void BorrarDepartamento(int id);
	public void ActualizarDepartamento(departamento dept,int id);
	public List<departamento> getAlldepartamento();
	public departamento getDepartamentById(int id);
	public int idNuevo();
	public int getTotalElementos();
	public List<departamento> getElementosPagina(int pg,int nele);
	}
