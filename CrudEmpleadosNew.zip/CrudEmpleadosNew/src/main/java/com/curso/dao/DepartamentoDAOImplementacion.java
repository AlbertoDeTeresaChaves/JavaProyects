package com.curso.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.Statement;

import com.curso.modelo.departamento;
import com.curso.util.DBUtil;

public class DepartamentoDAOImplementacion implements DepartamentoDAO {

	private Connection conn;
	
	public DepartamentoDAOImplementacion() {
		conn = DBUtil.getConnection();
	}
	
	@Override
	public void AñadirDepartamento(departamento dept) {
		// TODO Auto-generated method stub
		try {
			String query ="insert into dept values(?,?,?)";
			PreparedStatement s = conn.prepareStatement(query);
			s.setInt(1, dept.getDEPTNO());
			s.setString(2,dept.getDNAME());
			s.setString(3, dept.getLOC());
			
			s.executeUpdate();
			s.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void BorrarDepartamento(int id) {
		// TODO Auto-generated method stub
		try {
			String query = "delete from dept where DEPTNO=?";
			PreparedStatement s = conn.prepareStatement(query);
			s.setInt(1, id);
			s.executeUpdate();
			s.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void ActualizarDepartamento(departamento dept, int id) {
		// TODO Auto-generated method stub
		try {
			String query="update dept set DEPTNO=?,DNAME=?,LOC=? where DEPTNO=?";
			PreparedStatement s = conn.prepareStatement(query);
			s.setInt(1, dept.getDEPTNO());
			s.setString(2, dept.getDNAME());
			s.setString(3,dept.getLOC());
			s.setInt(4, id);
			
			s.executeUpdate();
			s.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<departamento> getAlldepartamento() {
		// TODO Auto-generated method stub
		List<departamento> le = new ArrayList<departamento>();
		try {
			Statement statement = conn.createStatement();
			ResultSet r = statement.executeQuery("select * from dept");
			while(r.next()) {
				departamento de = new departamento();
				de.setDEPTNO(r.getInt(1));
				de.setDNAME(r.getString(2));
				de.setLOC(r.getString(3));
				le.add(de);
			}
			r.close();
			statement.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return le;
	}

	@Override
	public departamento getDepartamentById(int id) {
		// TODO Auto-generated method stub
		departamento de = new departamento();
		try {
			String query = "select * from dept where DEPTNO=?";
			PreparedStatement preparedStatement = conn.prepareStatement(query);
			preparedStatement.setInt(1, id);
			ResultSet r = preparedStatement.executeQuery();
			while(r.next()) {
				de.setDEPTNO(r.getInt(1));
				de.setDNAME(r.getString(2));
				de.setLOC(r.getString(3));
			}
			r.close();
			preparedStatement.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return de;
	}

	@Override
	public int idNuevo() {
		// TODO Auto-generated method stub
		int n=0;
		try {
			String query = "select max(DEPTNO)+1 from dept";
			PreparedStatement preparedStatement = conn.prepareStatement(query);
			ResultSet r = preparedStatement.executeQuery();
			while(r.next()) {
				n=r.getInt(1);
			}
			r.close();
			preparedStatement.close();
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
		return n;
	}

	@Override
	public int getTotalElementos() {
		// TODO Auto-generated method stub
		int n=0;
		try {
			String query = "select count(*) from dept";
			PreparedStatement preparedStatement = conn.prepareStatement(query);
			ResultSet r = preparedStatement.executeQuery();
			while(r.next()) {
				n=r.getInt(1);
			}
			r.close();
			preparedStatement.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return n;
	}

	@Override
	public List<departamento> getElementosPagina(int pg, int nele) {
		// TODO Auto-generated method stub
		int ini=pg*nele;
		List<departamento>le = new ArrayList<departamento>();
		try{
			Statement statement = conn.createStatement();
			ResultSet r = statement.executeQuery("select * from dept limit "+ini+","+nele);
			while(r.next()) {
				departamento de = new departamento();
				de.setDEPTNO(r.getInt(1));
				de.setDNAME(r.getString(2));
				de.setLOC(r.getString(3));
				le.add(de);
			}
			r.close();
			statement.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return le;
	}

}
