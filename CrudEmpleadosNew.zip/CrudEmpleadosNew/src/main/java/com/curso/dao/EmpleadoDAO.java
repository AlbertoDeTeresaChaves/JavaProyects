package com.curso.dao;

import java.util.List;

import com.curso.modelo.departamento;
import com.curso.modelo.empleado;

public interface EmpleadoDAO {

	public void AñadirEmpleado(empleado emp);
	public void BorrarEmpleado(int id);
	public void ActualizarEmpleado(empleado emp,int id);
	public List <empleado> getAllempleados();
	public List <String> getAlljobs();
	public empleado getempleadoById(int id);
	public int idNuevo();
	public List <departamento> getAlldepartamentos();
	public List <empleado> getAlljefes();
}
